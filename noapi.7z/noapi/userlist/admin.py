from django.contrib import admin

# Register your models here.
from userlist.models import Ban_user

admin.site.register(Ban_user)