from django.apps import AppConfig


class UserlistConfig(AppConfig):
    name = 'userlist'
