from django.db import models

# Create your models here.


class Ban_user(models.Model):
    name = models.CharField(max_length=1000)